package com.example.viewstudentmark.Controller;

import com.example.viewstudentmark.Entity.Student;
import com.example.viewstudentmark.Repository.StudentRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class StudentController {
    private final StudentRepository studentRepository;

    public StudentController(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @GetMapping("/add-student")
    public String showAddStudentForm(Model model) {
        model.addAttribute("student", new Student());
        return "add-student";
    }

    @PostMapping("/add")
    public String addStudent(Student student, Model model) {
        studentRepository.save(student);
        // Clear the form by providing an empty student object to the form
        model.addAttribute("student", new Student());
        return "redirect:/students/view";
  }



    @GetMapping("/view")
    public String viewStudents(Model model) {
        model.addAttribute("students", studentRepository.findAll());
        return "view-students";
    }
}