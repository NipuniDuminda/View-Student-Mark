package com.example.viewstudentmark;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViewStudentMarkApplicationTests {

    @Test
    void contextLoads() {
    }

}
